1:"$Sreact.fragment"
2:I[45678,["/_next/static/chunks/0dbhjjzl8qfwv.js","/_next/static/chunks/0xt1gglio__cg.js"],"default"]
3:I[13642,["/_next/static/chunks/0dbhjjzl8qfwv.js","/_next/static/chunks/0xt1gglio__cg.js"],"default"]
4:I[97367,["/_next/static/chunks/0dbhjjzl8qfwv.js"],"OutletBoundary"]
5:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[[["$","$L2",null,{}],["$","div",null,{"style":{"marginTop":"64px"},"children":["$","iframe",null,{"src":"/guide.html","style":{"width":"100%","height":"calc(100vh - 64px)","border":"none","display":"block"},"title":"桥本疗愈指南","allow":"fullscreen"}]}],["$","$L3",null,{}]],[["$","script","script-0",{"src":"/_next/static/chunks/0xt1gglio__cg.js","async":true}]],["$","$L4",null,{"children":["$","$5",null,{"name":"Next.MetadataOutlet","children":"$@6"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"cwXTp-qCngitSyHD_zVFk"}
6:null
