module.exports=[19036,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_youzan_page_actions_0lszvxj.js.map